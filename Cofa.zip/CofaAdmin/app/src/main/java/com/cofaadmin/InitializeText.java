package com.cofaadmin;

public class InitializeText {
    public InitializeText() {
    }

    static String retrieveText;

    public static String getRetrieveText() {
        return retrieveText;
    }

    public static void setRetrieveText(String retrieveText) {
        InitializeText.retrieveText = retrieveText;
    }
}
