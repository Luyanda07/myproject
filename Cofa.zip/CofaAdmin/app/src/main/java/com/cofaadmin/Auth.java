package com.cofaadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Auth extends AppCompatActivity {

    Button patient, doctor, admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        patient = findViewById(R.id.patient_btn);
        doctor = findViewById(R.id.doctor_btn);
        admin = findViewById(R.id.admin_btn);

        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(Auth.this, PatientAuth.class);
                startActivity(a);
            }
        });

        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(Auth.this, Doctor.class);
                startActivity(a);
            }
        });

        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(Auth.this, Admin.class);
                startActivity(a);
            }
        });
    }
}