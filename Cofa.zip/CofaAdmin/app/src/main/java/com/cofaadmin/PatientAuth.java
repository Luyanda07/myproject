package com.cofaadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.concurrent.Executor;

public class PatientAuth extends AppCompatActivity {

    ImageView fingerprint;
    Button login;
    EditText id, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_auth);

        fingerprint = findViewById(R.id.fingerprint);
        login = findViewById(R.id.patient_login_btn);
        id= findViewById(R.id.patient_id);
        pass = findViewById(R.id.patient_password);

        fingerprint.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                fingerprint.setBackgroundColor(Color.parseColor("#22ff00"));
                Intent a = new Intent(PatientAuth.this, Patient.class);
                startActivity(a);
                return true;
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String getId = id.getText().toString().trim(), getPass = pass.getText().toString().trim();

                if (!getId.isEmpty() && !getPass.isEmpty()){
                    if (getId.equals("9804046108086") && getPass.equals("12345")){
                        Intent a = new Intent(PatientAuth.this, Patient.class);
                        startActivity(a);
                    }
                    else {
                        Toast.makeText(PatientAuth.this, "Email/Password incorrect", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(PatientAuth.this, "Patient not registered", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}