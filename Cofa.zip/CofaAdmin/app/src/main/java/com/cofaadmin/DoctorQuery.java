package com.cofaadmin;

public class DoctorQuery {
    public DoctorQuery() {
    }

    public static String getQuery() {
        return query;
    }

    public static void setQuery(String query) {
        DoctorQuery.query = query;
    }

    static String query;
}
